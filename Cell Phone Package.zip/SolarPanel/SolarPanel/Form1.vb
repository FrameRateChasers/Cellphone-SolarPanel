﻿Public Class Form1

    Const Express_Price As Double = 1.05
    Const Price_for_Addtional As Double = 300

    Dim dblPriceForAddtionalPanel As Double
    Dim intBasePrice As Integer = 2000
    Dim dblPriceAfterExpressOpition As Double
    Dim dblDepsotAmnt As Double
    Dim intBalanceDue As Integer
    Dim intNumeOfPanel As Integer
    Dim TotalCost As Integer
     Dim dblbalancedue As Double

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCheckForError.Click
        CheckForError()
    End Sub
    Private Sub mnuOptions_Click(sender As Object, e As EventArgs) Handles mnuOptions.Click
        CheckUserInfo()
    End Sub
    Private Sub mnuCharges_Click(sender As Object, e As EventArgs) Handles mnuCharges.Click

        ShowResults()
        lblBaseCharge.Text = intBasePrice.ToString("c")
        lblAdditionalPanel.Text = MathForAdditionalPanels().ToString("c")

        TotalCost = (MathForAdditionalPanels() + intBasePrice) * ExpressCharge()

        lblTotalCost.Text = TotalCost.ToString("c")
        Double.TryParse(txtDepostAmnt.Text, dblDepsotAmnt)
        lblDepositAmnt.Text = dblDepsotAmnt.ToString("c")
        Dim dblbalancedue As Double = TotalCost - dblDepsotAmnt
        If dblbalancedue < -1 Then
            dblbalancedue *= -1
            Label5.Visible = False
            Label6.Visible = True
            lblBalanceDue.Text = dblbalancedue.ToString("c")
            MsgBox("your refund is" & " " & dblbalancedue & " " & "dollars")
        Else
            lblBalanceDue.Text = dblbalancedue.ToString("c")
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub





    Private Sub CheckForError()
        If txtNumPanel.Text = String.Empty Or Not Integer.TryParse(txtNumPanel.Text, intNumeOfPanel) Then
            ToolStripStatusLabel2.Text = "please do not leave number of panels empty and enter numeric digits between 2-1000"
            MsgBox("please do not leave number of panels empty and enter numeric digits between 2-1000")
            If Not Double.TryParse(txtDepostAmnt.Text, dblDepsotAmnt) Then
                ToolStripStatusLabel2.Text = "please enter a positive numeric digit in deposit amount"
                MsgBox("please enter a positive numeric digit in deposit amount")
            End If
        Else
            lblCheckForError.Visible = True
            mnuCharges.Enabled = True
        End If
    End Sub
    Private Sub CheckUserInfo()
        If TextBox1.Text = String.Empty Or TextBox2.Text = String.Empty Or TextBox3.Text = String.Empty Then
            ToolStripStatusLabel2.Text = "please do not leave any field empty"
            MsgBox("please do not leave any field empty")
        Else
            Label14.Visible = True
            Label15.Visible = True
            txtDepostAmnt.Visible = True
            txtNumPanel.Visible = True
            chkExpress.Visible = True
            btnCheckForError.Visible = True
        End If
    End Sub
    Private Sub ShowResults()
        lblAdditionalPanel.Visible = True
        lblBalanceDue.Visible = True
        lblBaseCharge.Visible = True
        lblDepositAmnt.Visible = True
        lblTotalCost.Visible = True
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        btnClear.Visible = True
        btnClose.Visible = True
    End Sub
    Private Function MathForAdditionalPanels() As Integer
        Dim x As Integer
        Integer.TryParse(txtNumPanel.Text, intNumeOfPanel)
        x = (intNumeOfPanel - 2) * Price_for_Addtional
        Return x
    End Function

    Private Function ExpressCharge()
        Dim x As Double
        If chkExpress.Checked = True Then
            x = Express_Price
        Else
            x = 0
        End If
        Return x
    End Function

    Private Sub HideResultsClearInputs()

        lblAdditionalPanel.Text = ""
        lblBalanceDue.Text = ""
        lblBaseCharge.Text = ""
        lblDepositAmnt.Text = ""
        lblTotalCost.Text = ""

        Label14.Visible = False
        Label15.Visible = False
        txtDepostAmnt.Text = ""
        txtNumPanel.Text = ""
        txtNumPanel.Visible = False
        txtDepostAmnt.Visible = False
        chkExpress.Checked = False
        chkExpress.Visible = False

        lblCheckForError.Visible = False
        btnCheckForError.Visible = False
        lblAdditionalPanel.Visible = False
        lblBalanceDue.Visible = False
        lblBaseCharge.Visible = False
        lblDepositAmnt.Visible = False
        lblTotalCost.Visible = False
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        btnClear.Visible = False
        btnClose.Visible = False



    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        HideResultsClearInputs()
        mnuCharges.Enabled = False
    End Sub
End Class
