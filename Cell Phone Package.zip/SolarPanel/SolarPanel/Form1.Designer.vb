﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnCheckForError = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblAdditionalPanel = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.lblDepositAmnt = New System.Windows.Forms.Label()
        Me.lblBalanceDue = New System.Windows.Forms.Label()
        Me.lblBaseCharge = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.txtNumPanel = New System.Windows.Forms.TextBox()
        Me.txtDepostAmnt = New System.Windows.Forms.TextBox()
        Me.chkExpress = New System.Windows.Forms.CheckBox()
        Me.lblCheckForError = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FILEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.CUSTOMERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInformation = New System.Windows.Forms.ToolStripMenuItem()
        Me.INSTALLATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCharges = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCheckForError
        '
        Me.btnCheckForError.Location = New System.Drawing.Point(310, 32)
        Me.btnCheckForError.Name = "btnCheckForError"
        Me.btnCheckForError.Size = New System.Drawing.Size(139, 50)
        Me.btnCheckForError.TabIndex = 2
        Me.btnCheckForError.Text = "CHECK FOR ERRORS"
        Me.btnCheckForError.UseVisualStyleBackColor = True
        Me.btnCheckForError.Visible = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(322, 405)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(139, 50)
        Me.btnClose.TabIndex = 4
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = True
        Me.btnClose.Visible = False
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(322, 334)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(139, 50)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        Me.btnClear.Visible = False
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(23, 334)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 28)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "BASE CHARGE FOR TWO PANELS:"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(23, 372)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(136, 23)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "ADDITIONAL PANELS:"
        Me.Label2.Visible = False
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(23, 405)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 24)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "TOTAL COST:"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(23, 441)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(136, 24)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "DEPOSIT AMOUNT:"
        Me.Label4.Visible = False
        '
        'lblAdditionalPanel
        '
        Me.lblAdditionalPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAdditionalPanel.Location = New System.Drawing.Point(191, 372)
        Me.lblAdditionalPanel.Name = "lblAdditionalPanel"
        Me.lblAdditionalPanel.Size = New System.Drawing.Size(96, 23)
        Me.lblAdditionalPanel.TabIndex = 11
        Me.lblAdditionalPanel.Visible = False
        '
        'lblTotalCost
        '
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Location = New System.Drawing.Point(191, 405)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(96, 24)
        Me.lblTotalCost.TabIndex = 12
        Me.lblTotalCost.Visible = False
        '
        'lblDepositAmnt
        '
        Me.lblDepositAmnt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDepositAmnt.Location = New System.Drawing.Point(191, 441)
        Me.lblDepositAmnt.Name = "lblDepositAmnt"
        Me.lblDepositAmnt.Size = New System.Drawing.Size(96, 24)
        Me.lblDepositAmnt.TabIndex = 13
        Me.lblDepositAmnt.Visible = False
        '
        'lblBalanceDue
        '
        Me.lblBalanceDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBalanceDue.Location = New System.Drawing.Point(191, 474)
        Me.lblBalanceDue.Name = "lblBalanceDue"
        Me.lblBalanceDue.Size = New System.Drawing.Size(96, 24)
        Me.lblBalanceDue.TabIndex = 14
        Me.lblBalanceDue.Visible = False
        '
        'lblBaseCharge
        '
        Me.lblBaseCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBaseCharge.Location = New System.Drawing.Point(191, 333)
        Me.lblBaseCharge.Name = "lblBaseCharge"
        Me.lblBaseCharge.Size = New System.Drawing.Size(96, 24)
        Me.lblBaseCharge.TabIndex = 15
        Me.lblBaseCharge.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(33, 98)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 13)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "FIRST NAME"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(33, 128)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 13)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "LAST NAME"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(319, 87)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "PHONE"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(24, 207)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(116, 13)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "NUMBER OF PANELS"
        Me.Label14.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 235)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(104, 13)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "DEPOSIT AMOUNT"
        Me.Label15.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(129, 98)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 22
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(129, 128)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 23
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(306, 125)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 24
        '
        'txtNumPanel
        '
        Me.txtNumPanel.Location = New System.Drawing.Point(146, 204)
        Me.txtNumPanel.Name = "txtNumPanel"
        Me.txtNumPanel.Size = New System.Drawing.Size(100, 20)
        Me.txtNumPanel.TabIndex = 25
        Me.txtNumPanel.Visible = False
        '
        'txtDepostAmnt
        '
        Me.txtDepostAmnt.Location = New System.Drawing.Point(146, 235)
        Me.txtDepostAmnt.Name = "txtDepostAmnt"
        Me.txtDepostAmnt.Size = New System.Drawing.Size(100, 20)
        Me.txtDepostAmnt.TabIndex = 26
        Me.txtDepostAmnt.Visible = False
        '
        'chkExpress
        '
        Me.chkExpress.AutoSize = True
        Me.chkExpress.Location = New System.Drawing.Point(74, 261)
        Me.chkExpress.Name = "chkExpress"
        Me.chkExpress.Size = New System.Drawing.Size(172, 17)
        Me.chkExpress.TabIndex = 29
        Me.chkExpress.Text = "EXPRESS INSTALLAION (5%)"
        Me.chkExpress.UseVisualStyleBackColor = True
        Me.chkExpress.Visible = False
        '
        'lblCheckForError
        '
        Me.lblCheckForError.AutoSize = True
        Me.lblCheckForError.ForeColor = System.Drawing.Color.Lime
        Me.lblCheckForError.Location = New System.Drawing.Point(262, 99)
        Me.lblCheckForError.Name = "lblCheckForError"
        Me.lblCheckForError.Size = New System.Drawing.Size(187, 13)
        Me.lblCheckForError.TabIndex = 32
        Me.lblCheckForError.Text = "INSTALLATION OPTIONS VERIFIED"
        Me.lblCheckForError.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FILEToolStripMenuItem, Me.CUSTOMERToolStripMenuItem, Me.INSTALLATIONToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(498, 24)
        Me.MenuStrip1.TabIndex = 33
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FILEToolStripMenuItem
        '
        Me.FILEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClear, Me.mnuExit})
        Me.FILEToolStripMenuItem.Name = "FILEToolStripMenuItem"
        Me.FILEToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FILEToolStripMenuItem.Text = "FILE"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(152, 22)
        Me.mnuClear.Text = "CLEAR"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuExit.Text = "EXIT"
        '
        'CUSTOMERToolStripMenuItem
        '
        Me.CUSTOMERToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuInformation})
        Me.CUSTOMERToolStripMenuItem.Name = "CUSTOMERToolStripMenuItem"
        Me.CUSTOMERToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.CUSTOMERToolStripMenuItem.Text = "CUSTOMER"
        '
        'mnuInformation
        '
        Me.mnuInformation.Name = "mnuInformation"
        Me.mnuInformation.Size = New System.Drawing.Size(154, 22)
        Me.mnuInformation.Text = "INFORMATION"
        '
        'INSTALLATIONToolStripMenuItem
        '
        Me.INSTALLATIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOptions, Me.mnuCharges})
        Me.INSTALLATIONToolStripMenuItem.Name = "INSTALLATIONToolStripMenuItem"
        Me.INSTALLATIONToolStripMenuItem.Size = New System.Drawing.Size(98, 20)
        Me.INSTALLATIONToolStripMenuItem.Text = "INSTALLATION"
        '
        'mnuOptions
        '
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(126, 22)
        Me.mnuOptions.Text = "OPTION"
        '
        'mnuCharges
        '
        Me.mnuCharges.Enabled = False
        Me.mnuCharges.Name = "mnuCharges"
        Me.mnuCharges.Size = New System.Drawing.Size(126, 22)
        Me.mnuCharges.Text = "CHARGES"
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(12, 60)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(474, 100)
        Me.GroupBox1.TabIndex = 34
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CUSTOMER INFORMATION"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.GroupBox2.Controls.Add(Me.lblCheckForError)
        Me.GroupBox2.Controls.Add(Me.btnCheckForError)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 166)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(474, 133)
        Me.GroupBox2.TabIndex = 35
        Me.GroupBox2.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 315)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(474, 199)
        Me.GroupBox3.TabIndex = 36
        Me.GroupBox3.TabStop = False
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(12, 159)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(136, 23)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "REFUND:"
        Me.Label6.Visible = False
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(12, 159)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(136, 23)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "BALANCE DUE:"
        Me.Label5.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 518)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(498, 22)
        Me.StatusStrip1.TabIndex = 37
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.BackColor = System.Drawing.Color.Red
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel2.Text = "Status"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(498, 540)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.chkExpress)
        Me.Controls.Add(Me.txtDepostAmnt)
        Me.Controls.Add(Me.txtNumPanel)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblBaseCharge)
        Me.Controls.Add(Me.lblBalanceDue)
        Me.Controls.Add(Me.lblDepositAmnt)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblAdditionalPanel)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCheckForError As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblAdditionalPanel As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents lblDepositAmnt As Label
    Friend WithEvents lblBalanceDue As Label
    Friend WithEvents lblBaseCharge As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents txtNumPanel As TextBox
    Friend WithEvents txtDepostAmnt As TextBox
    Friend WithEvents chkExpress As CheckBox
    Friend WithEvents lblCheckForError As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FILEToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents CUSTOMERToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuInformation As ToolStripMenuItem
    Friend WithEvents INSTALLATIONToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuOptions As ToolStripMenuItem
    Friend WithEvents mnuCharges As ToolStripMenuItem
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
End Class
