﻿Public Class PhonePackage
    Private Sub btnIndi_Click(sender As Object, e As EventArgs) Handles btnIndi.Click
        Dim frmIndi As New IndividualPlan
        frmIndi.ShowDialog()
    End Sub

    Private Sub btnFam_Click(sender As Object, e As EventArgs) Handles btnFam.Click
        Dim frmFamily As New FamilyPlan
        frmFamily.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
