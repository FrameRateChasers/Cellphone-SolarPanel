﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IndividualPlan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblPhoneTotalOutput = New System.Windows.Forms.Label()
        Me.lblTaxOutput = New System.Windows.Forms.Label()
        Me.lblPhoneSubOutput = New System.Windows.Forms.Label()
        Me.lblTotalMonthChargeOutput = New System.Windows.Forms.Label()
        Me.lblPackageChargeOutput = New System.Windows.Forms.Label()
        Me.lblOptionOutput = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.chkEmail = New System.Windows.Forms.CheckBox()
        Me.chkTM = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.radM200 = New System.Windows.Forms.RadioButton()
        Me.radM110 = New System.Windows.Forms.RadioButton()
        Me.radM100 = New System.Windows.Forms.RadioButton()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.radUnlimited = New System.Windows.Forms.RadioButton()
        Me.rad1500Month = New System.Windows.Forms.RadioButton()
        Me.rad800Month = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(251, 242)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Phone Subtotal"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(251, 275)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(25, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tax"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(251, 309)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Phone Total"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(251, 407)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Total Monthly Charge"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(251, 373)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Package Charge"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(251, 340)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Options"
        '
        'lblPhoneTotalOutput
        '
        Me.lblPhoneTotalOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPhoneTotalOutput.Location = New System.Drawing.Point(376, 298)
        Me.lblPhoneTotalOutput.Name = "lblPhoneTotalOutput"
        Me.lblPhoneTotalOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblPhoneTotalOutput.TabIndex = 8
        '
        'lblTaxOutput
        '
        Me.lblTaxOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTaxOutput.Location = New System.Drawing.Point(376, 264)
        Me.lblTaxOutput.Name = "lblTaxOutput"
        Me.lblTaxOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblTaxOutput.TabIndex = 7
        '
        'lblPhoneSubOutput
        '
        Me.lblPhoneSubOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPhoneSubOutput.Location = New System.Drawing.Point(376, 231)
        Me.lblPhoneSubOutput.Name = "lblPhoneSubOutput"
        Me.lblPhoneSubOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblPhoneSubOutput.TabIndex = 6
        '
        'lblTotalMonthChargeOutput
        '
        Me.lblTotalMonthChargeOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMonthChargeOutput.Location = New System.Drawing.Point(376, 396)
        Me.lblTotalMonthChargeOutput.Name = "lblTotalMonthChargeOutput"
        Me.lblTotalMonthChargeOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblTotalMonthChargeOutput.TabIndex = 11
        '
        'lblPackageChargeOutput
        '
        Me.lblPackageChargeOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPackageChargeOutput.Location = New System.Drawing.Point(376, 362)
        Me.lblPackageChargeOutput.Name = "lblPackageChargeOutput"
        Me.lblPackageChargeOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblPackageChargeOutput.TabIndex = 10
        '
        'lblOptionOutput
        '
        Me.lblOptionOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOptionOutput.Location = New System.Drawing.Point(376, 329)
        Me.lblOptionOutput.Name = "lblOptionOutput"
        Me.lblOptionOutput.Size = New System.Drawing.Size(86, 24)
        Me.lblOptionOutput.TabIndex = 9
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(32, 313)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(138, 47)
        Me.btnCalc.TabIndex = 12
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(32, 373)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(138, 47)
        Me.btnExit.TabIndex = 13
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'chkEmail
        '
        Me.chkEmail.AutoSize = True
        Me.chkEmail.Location = New System.Drawing.Point(6, 33)
        Me.chkEmail.Name = "chkEmail"
        Me.chkEmail.Size = New System.Drawing.Size(51, 17)
        Me.chkEmail.TabIndex = 14
        Me.chkEmail.Text = "Email"
        Me.chkEmail.UseVisualStyleBackColor = True
        '
        'chkTM
        '
        Me.chkTM.AutoSize = True
        Me.chkTM.Location = New System.Drawing.Point(6, 56)
        Me.chkTM.Name = "chkTM"
        Me.chkTM.Size = New System.Drawing.Size(101, 17)
        Me.chkTM.TabIndex = 15
        Me.chkTM.Text = "Text Messaging"
        Me.chkTM.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkTM)
        Me.GroupBox1.Controls.Add(Me.chkEmail)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 188)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(156, 89)
        Me.GroupBox1.TabIndex = 16
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Options"
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(239, 188)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(238, 247)
        Me.GroupBox2.TabIndex = 17
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Totals"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.radM200)
        Me.GroupBox3.Controls.Add(Me.radM110)
        Me.GroupBox3.Controls.Add(Me.radM100)
        Me.GroupBox3.Location = New System.Drawing.Point(38, 38)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox3.TabIndex = 18
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Select a Phone"
        '
        'radM200
        '
        Me.radM200.AutoSize = True
        Me.radM200.Location = New System.Drawing.Point(11, 65)
        Me.radM200.Name = "radM200"
        Me.radM200.Size = New System.Drawing.Size(75, 17)
        Me.radM200.TabIndex = 22
        Me.radM200.TabStop = True
        Me.radM200.Text = "Model 200"
        Me.radM200.UseVisualStyleBackColor = True
        '
        'radM110
        '
        Me.radM110.AutoSize = True
        Me.radM110.Location = New System.Drawing.Point(11, 42)
        Me.radM110.Name = "radM110"
        Me.radM110.Size = New System.Drawing.Size(75, 17)
        Me.radM110.TabIndex = 21
        Me.radM110.TabStop = True
        Me.radM110.Text = "Model 110"
        Me.radM110.UseVisualStyleBackColor = True
        '
        'radM100
        '
        Me.radM100.AutoSize = True
        Me.radM100.Location = New System.Drawing.Point(11, 19)
        Me.radM100.Name = "radM100"
        Me.radM100.Size = New System.Drawing.Size(75, 17)
        Me.radM100.TabIndex = 20
        Me.radM100.TabStop = True
        Me.radM100.Text = "Model 100"
        Me.radM100.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.radUnlimited)
        Me.GroupBox4.Controls.Add(Me.rad1500Month)
        Me.GroupBox4.Controls.Add(Me.rad800Month)
        Me.GroupBox4.Location = New System.Drawing.Point(262, 38)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox4.TabIndex = 19
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Select a Package"
        '
        'radUnlimited
        '
        Me.radUnlimited.AutoSize = True
        Me.radUnlimited.Location = New System.Drawing.Point(7, 65)
        Me.radUnlimited.Name = "radUnlimited"
        Me.radUnlimited.Size = New System.Drawing.Size(140, 17)
        Me.radUnlimited.TabIndex = 25
        Me.radUnlimited.TabStop = True
        Me.radUnlimited.Text = "Unlimited Min Per Month"
        Me.radUnlimited.UseVisualStyleBackColor = True
        '
        'rad1500Month
        '
        Me.rad1500Month.AutoSize = True
        Me.rad1500Month.Location = New System.Drawing.Point(7, 42)
        Me.rad1500Month.Name = "rad1500Month"
        Me.rad1500Month.Size = New System.Drawing.Size(121, 17)
        Me.rad1500Month.TabIndex = 24
        Me.rad1500Month.TabStop = True
        Me.rad1500Month.Text = "1500 Min Per Month"
        Me.rad1500Month.UseVisualStyleBackColor = True
        '
        'rad800Month
        '
        Me.rad800Month.AutoSize = True
        Me.rad800Month.Location = New System.Drawing.Point(7, 19)
        Me.rad800Month.Name = "rad800Month"
        Me.rad800Month.Size = New System.Drawing.Size(115, 17)
        Me.rad800Month.TabIndex = 23
        Me.rad800Month.TabStop = True
        Me.rad800Month.Text = "800 Min Per Month"
        Me.rad800Month.UseVisualStyleBackColor = True
        '
        'Individual_Plan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 452)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblTotalMonthChargeOutput)
        Me.Controls.Add(Me.lblPackageChargeOutput)
        Me.Controls.Add(Me.lblOptionOutput)
        Me.Controls.Add(Me.lblPhoneTotalOutput)
        Me.Controls.Add(Me.lblTaxOutput)
        Me.Controls.Add(Me.lblPhoneSubOutput)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "Individual_Plan"
        Me.Text = "Individual_Plan"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblPhoneTotalOutput As Label
    Friend WithEvents lblTaxOutput As Label
    Friend WithEvents lblPhoneSubOutput As Label
    Friend WithEvents lblTotalMonthChargeOutput As Label
    Friend WithEvents lblPackageChargeOutput As Label
    Friend WithEvents lblOptionOutput As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents chkEmail As CheckBox
    Friend WithEvents chkTM As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents radM200 As RadioButton
    Friend WithEvents radM110 As RadioButton
    Friend WithEvents radM100 As RadioButton
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents radUnlimited As RadioButton
    Friend WithEvents rad1500Month As RadioButton
    Friend WithEvents rad800Month As RadioButton
End Class
