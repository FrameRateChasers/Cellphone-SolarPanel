﻿Public Class FamilyPlan

    Public Const firstplan_perMonth As Double = 45.0
    Public Const secoundtplan_perMonth As Double = 65.0
    Public Const unlimited_perMonth As Double = 99.0
    Public Const email_price As Double = 25.0
    Public Const unlimited_text As Double = 10.0
    Public Const phone_modle100 As Double = 29.95
    Public Const phone_modle110 As Double = 49.95
    Public Const phone_modle200 As Double = 99.95
    Public Const sales_tax As Double = 1.06
    Dim dblTextInput As Double
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click






        If radM100.Checked = False And radM110.Checked = False And radM200.Checked = False Then
                MsgBox("please choose a cell phone")
            ElseIf rad800Month.Checked = False And rad1500Month.Checked = False And radUnlimited.Checked = False Then
                MsgBox("please choose a cell phone plan")
            ElseIf txtInput.Text = String.Empty Or Not Double.TryParse(txtInput.Text, dblTextInput) Then
                MsgBox("please do not leave number of phones empty and enter numeric values greater than 0")
            Else





                'Double.TryParse(txtInput.Text, dblTextInput)


                'price of just the phone
                lblPhoneSubOutput.Text = PriceOfPhoneSubTotal().ToString("c")

                'price of sales tax
                lblTaxOutput.Text = PriceOfSalesTax().ToString("c")

                'price of phone after tax
                lblPhoneTotalOutput.Text = PriceOfPhoneAfterTax().ToString("c")

                'price of options
                lblOptionOutput.Text = PriceOfOptions().ToString("c")

                'price of cell phone packages
                lblPackageChargeOutput.Text = PriceOfPhonePackages().ToString("c")

                'monthly charge
                Dim intHold As Double = PriceOfOptions() + PriceOfPhonePackages()
                lblTotalMonthChargeOutput.Text = intHold.ToString("c")


            End If



    End Sub


    Function PriceOfPhoneSubTotal() As Double
        Dim x As Double
        If radM100.Checked = True Then
            x += phone_modle100 * dblTextInput
        ElseIf radM110.Checked = True Then
            x += phone_modle110 * dblTextInput
        ElseIf radM200.Checked = True Then
            x += phone_modle200 * dblTextInput
        End If
        Return x
    End Function
    Function PriceOfSalesTax() As Double
        Dim x As Double = (sales_tax - 1) * PriceOfPhoneSubTotal()
        Return x
    End Function
    Function PriceOfPhoneAfterTax() As Double
        Dim x As Double
        x = PriceOfPhoneSubTotal() * sales_tax
        Return x
    End Function
    Function PriceOfOptions() As Double
        Dim x As Double
        If chkEmail.Checked = True And chkTM.Checked = True Then
            x += email_price + unlimited_text * dblTextInput
        ElseIf chkTM.Checked = True Then
            x += unlimited_text * dblTextInput
        ElseIf chkEmail.Checked = True Then
            x += email_price * dblTextInput
        End If
        Return x
    End Function
    Function PriceOfPhonePackages() As Double
        Dim x As Double
        If rad800Month.Checked = True Then
            x += firstplan_perMonth
        ElseIf rad1500Month.Checked = True Then
            x += secoundtplan_perMonth
        ElseIf radUnlimited.Checked = True Then
            x += unlimited_perMonth
        End If
        Return x
    End Function

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class